# xlop launcher

لانشر ماين كرافت (Java Edition). التشغيل: `xlop-launcher` أو من قائمة التطبيقات.

## الحسابات
- **أوفلاين:** اكتب أي اسم. يصلح للعب الفردي وللسيرفرات التي `online-mode=false`.
- **Ely.by:** اسم المستخدم/البريد وكلمة المرور (ورمز المصادقة الثنائية إن كان مفعّلًا).
- **Microsoft:** الضغط على «+ Microsoft» يعرض كودًا ويفتح صفحة microsoft.com/link؛ أدخل الكود، سجّل
  الدخول بحسابك ووافق، فيكتمل الدخول داخل اللانشر تلقائيًا. المستخدم لا يكتب أي معرّف.

## النسخ
تُقرأ قائمة النسخ من خوادم Mojang مباشرة، فتظهر كل نسخة جديدة (مثل 26.3) تلقائيًا.
تُنزَّل نسخة Java المناسبة لكل نسخة من Mojang. النسخ المثبّتة يدويًا (مثل Fabric/Forge) داخل
`~/.minecraft/versions` تظهر كنسخ "محلية".

## السكنات
- أوفلاين: يُعرض السكن داخل اللعبة (1.7.2+) عبر خادم محلي وأداة authlib-injector.
- Microsoft: يُرفع السكن إلى حسابك الأصلي.
- Ely.by: تُدار السكنات من موقع Ely.by.

## سطر الأوامر
`xlop-launcher versions | accounts | add-offline NAME | add-ely USER | install VER | launch VER [--dry-run] | skin ACCOUNT FILE`

## تفعيل حساب Microsoft (مرة واحدة، من مالك اللانشر)
يطلب خادم Mojang أن يكون «معرّف التطبيق» معتمدًا، وإلا يرفض بـ `Invalid app registration`.

1. portal.azure.com ← App registrations ← New registration (لا تضع Mojang/Minecraft في الاسم).
   ثم Authentication ← Allow public client flows = Yes. انسخ **Application (client) ID**.
2. قدّم المعرّف لـ Mojang عبر النموذج: https://aka.ms/mce-reviewappid (الموافقة قرار Mojang).
3. بعد الموافقة ضع المعرّف مرة واحدة بإحدى الطرق:
   - `echo "ID" | sudo tee /etc/xlop-launcher/microsoft_client_id` (ملف إعداد، لا يُستبدل عند التحديث)
   - أو ضعه في `BUILTIN_CLIENT_ID` داخل `xlop/accounts.py` ثم أعد بناء الحزمة.
   المعرّف عام وآمن للنشر داخل البرنامج.

أوامر الطرفية: `xlop-launcher add-microsoft` يعرض الكود والرابط ثم ينتظر تسجيل الدخول.

## التحديث التلقائي
يفحص اللانشر عند التشغيل (مرة كل 6 ساعات) ملف `latest.json` من رابط التحديث. إذا وُجد إصدار أحدث يظهر شريط
«تحديث الآن»؛ يُنزَّل ملف deb ويُتحقق من بصمته (SHA256) واسم الحزمة ورقم الإصدار، ثم يُثبَّت عبر `pkexec`
(يطلب كلمة مرور النظام) ويُعاد تشغيل اللانشر. الحسابات والإعدادات لا تتأثر.
من الطرفية: `xlop-launcher update` أو `xlop-launcher update --check`. يمكن إيقاف الفحص من الإعدادات.

## نشر تحديث (لمالك اللانشر)
1. **مرة واحدة:** ضع رابط التحديث داخل الحزمة التي توزّعها:
   `sh bake-config.sh xlop-launcher_X_all.deb out.deb --update-url https://github.com/OWNER/REPO/releases/latest/download/latest.json`
   (الرابط `releases/latest/download/...` يشير دائمًا إلى أحدث إصدار في GitHub.)
2. **لكل إصدار جديد:** أنشئ Release في GitHub، ثم:
   `python3 make_update_manifest.py الحزمة.deb --url https://github.com/OWNER/REPO/releases/download/vX/الحزمة.deb --notes "ما الجديد"`
   وارفع الملفين (`.deb` و`latest.json`) إلى الـ Release. تصل النسخة الجديدة لكل من ثبّت اللانشر.
3. النسخ الأقدم من 1.1.0 لا تحتوي المُحدِّث، ويلزمها تثبيت يدوي واحد للنسخة الجديدة.
