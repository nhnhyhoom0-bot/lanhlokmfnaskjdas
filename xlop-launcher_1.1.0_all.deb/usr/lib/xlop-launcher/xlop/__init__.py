"""xlop launcher - a Minecraft: Java Edition launcher."""
VERSION = "1.1.0"
APP_NAME = "xlop launcher"
